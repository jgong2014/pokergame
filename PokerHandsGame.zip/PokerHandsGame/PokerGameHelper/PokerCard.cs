﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerGameHelper
{

    public enum CardSuits
    {
        Club = 1,
        Diamond = 2,
        Heart = 3,
        Spade = 4
    }

    public enum CardRanks
    {
        Two = 1,
        Three = 2,
        Four = 3,
        Five = 4,
        Six = 5,
        Seven = 6,
        Eight = 7,
        Nine = 8,
        Ten = 9,
        Jack = 10,
        Queen = 11,
        King = 12,
        Ace = 13
    }

    public class PokerCard:IComparable<PokerCard>
    {
        public int CardSuit { get; set; }
        public int CardRank { get; set; }

        public int CompareTo(PokerCard other)
        {
            if (other == null) { return 1; }
            else
            {
                if (this.CardRank > other.CardRank) { return 1; }
                else if (this.CardRank < other.CardRank) { return -1; }
                /* -- requirements did not specify comparing with suit, therefore treat same rank equal values. 
                 else
                {
                    if (this.CardSuit > other.CardSuit) { return 1; }
                    else if (this.CardSuit < other.CardSuit) { return -1; }
                    else return 0;
                }
                */
                else return 0;
            }
        }
    }

}
