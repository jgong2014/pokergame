﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerGameHelper
{
    public class PokerHand : IComparable<PokerHand>
    {
        public List<PokerCard> Cards { get; set; }
        public string PlayerName { get; set; }

        public PokerHand(string name)
        {
            PlayerName = name;
            Cards = new List<PokerCard>();
        }

        public bool HasFlush()
        {
            var GroupedCards = Cards.GroupBy(x => x.CardSuit).Where(y=>y.Count()==5);
            if (!GroupedCards.Any()) return false;
            return (Cards.Count == 5 && GroupedCards.First().AsEnumerable().ToList().Count == 5);
        }

        public bool HasThreeOfKind()
        {
            var GroupedCards = Cards.GroupBy(x => x.CardRank).Where(y => y.Count() == 3);
            if (!GroupedCards.Any()) return false;
            return (Cards.Count == 5 && GroupedCards.First().AsEnumerable().ToList().Count == 3);
        }

        public List<PokerCard> GetThreeOfKindCards()
        {
            return Cards.GroupBy(x => x.CardRank).Where(y => y.Count() == 3).First().AsEnumerable().ToList();
        }

        public bool HasOnePair()
        {
            //Commented out code below didn't pass unit testing. group by return 4 instead of 2 on unit testing line : 71 on UnitTestHand.cs
            //return (Cards.Count == 5 && Cards.GroupBy(x => x.CardRank).Count() == 2);
            var GroupedCards = Cards.GroupBy(x => x.CardRank).Where(y => y.Count() == 2);
            if (!GroupedCards.Any()) return false;
            return (Cards.Count == 5 && GroupedCards.First().AsEnumerable().ToList().Count == 2);
        }
        public List<PokerCard> GetOnePairCards()
        {
            return Cards.GroupBy(x => x.CardRank).Where(y => y.Count() == 2).First().AsEnumerable().ToList();
        }

        public int CompareTo(PokerHand other)
        {
            if (other == null) { return 1; }
            if (!other.Cards.Any()) { return 1; }
            if (this.HasFlush())
            {
                // other has no flush
                if (!other.HasFlush()) return 1;
                else
                {
                    //both hand has flush, now sorting both hands card, the bigger rank on front 
                    this.Cards.Sort();
                    other.Cards.Sort();
                    this.Cards.Reverse();
                    other.Cards.Reverse();
                    for (int index = 0; index < 5; index++)
                    {
                        if (this.Cards[index].CardRank > other.Cards[index].CardRank) { return 1; }
                        else if (this.Cards[index].CardRank < other.Cards[index].CardRank) { return -1; }
                    }
                    return 0;
                }
            }
            else if (this.HasThreeOfKind())
            {
                if (other.HasFlush()) { return -1; }
                else if (other.HasThreeOfKind())
                {
                    var handARank = this.GetThreeOfKindCards().First().CardRank;
                    var handBRank = other.GetThreeOfKindCards().First().CardRank;
                    if (handARank > handBRank) { return 1; }
                    else if (handARank == handBRank) { throw new Exception("Invalid sample data"); }
                    else { return -1; }
                }
                else { return 1; }
            }
            else if (this.HasOnePair())
            {
                if (other.HasFlush() || other.HasThreeOfKind()) { return -1; }
                else if (other.HasOnePair())
                {
                    var handARank = this.GetOnePairCards().First().CardRank;
                    var handBRank = other.GetOnePairCards().First().CardRank;
                    if (handARank > handBRank) { return 1; }
                    else if (handARank < handBRank) { return -1; }
                    else
                    {
                        return CompareHighCard(other);
                    }
                }
                else return 1;
            }
            else
            {
                if(other.HasFlush()||other.HasThreeOfKind() || other.HasOnePair()) { return -1; }
                else
                {
                    return CompareHighCard(other);
                }
            }
        }

        private int CompareHighCard(PokerHand other)
        {
            //both hand comparing high cards, now sorting both hands card, the bigger rank on front 
            this.Cards.Sort();
            other.Cards.Sort();
            this.Cards.Reverse();
            other.Cards.Reverse();
            for (int index = 0; index < 5; index++)
            {
                if (this.Cards[index].CardRank > other.Cards[index].CardRank) { return 1; }
                else if (this.Cards[index].CardRank < other.Cards[index].CardRank) { return -1; }
            }
            return 0;
        }
    }
}
