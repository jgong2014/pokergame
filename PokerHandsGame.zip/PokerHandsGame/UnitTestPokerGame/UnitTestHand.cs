﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerGameHelper;
using System;
using System.Collections.Generic;

namespace UnitTestPokerGame
{
    [TestClass]
    public class UnitTestHand
    {
        [TestMethod]
        public void TestPokerHand()
        {
            var Joe = new PokerHand("joe");

            //changed the rank value in the list
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });

            Joe.Cards.Sort(); //sort from small to high 
            Joe.Cards.Reverse(); //reverse order of sorted list

            Assert.AreEqual(Joe.Cards[0].CardRank, (int)CardRanks.King);
            Assert.AreEqual(Joe.Cards[4].CardRank, (int)CardRanks.Three);
        }

        [TestMethod]
        public void TestPokerHandFlush()
        {
            var Joe = new PokerHand("joe");

            //changed the rank value in the list
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Club });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });

            Assert.IsFalse(Joe.HasFlush());
        }

        [TestMethod]
        public void TestPokerHandHasThreeOfKind()
        {
            var Joe = new PokerHand("joe");

            //changed the rank value in the list
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Club });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });

            Assert.IsTrue(Joe.HasThreeOfKind());
        }

        [TestMethod]
        public void TestPokerHandOnePair()
        {
            var Joe = new PokerHand("joe");

            //changed the rank value in the list
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Club });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Club });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });

            Assert.IsTrue(Joe.HasOnePair());
        }

        [TestMethod]
        public void TestPokerHands()
        {
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Diamond });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            //Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });  //create missing card

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();

            list.Add(Joe);
            list.Add(Bob);
            list.Sort();
            list.Reverse();

            Assert.AreEqual(Bob, list[0]);
        }

        [TestMethod]
        public void TestCompareTwoPokerHands()
        {
            //compare 3 of kind
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Diamond });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();

            list.Add(Joe);
            list.Add(Bob);
            list.Sort();
            list.Reverse();

            Assert.AreEqual(Joe, list[0]);
        }

        [TestMethod]
        public void TestCompareTwoPokerHandsMethod1()
        {
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Diamond });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Heart });

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();

            list.Add(Joe);
            list.Add(Bob);
            list.Sort();  //same rank , nothing change , so bob added last , after reverse , bob is ahead of joe. 
            list.Reverse();

            Assert.AreEqual(Bob, list[0]);
        }
    }
}
