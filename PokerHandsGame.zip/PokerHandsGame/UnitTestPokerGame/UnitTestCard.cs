﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerGameHelper;
using System;

namespace UnitTestPokerGame
{
    [TestClass]
    public class UnitTestCard
    {
        [TestMethod]
        public void TestCompareSameSuitCards()
        {
            var cardA = new PokerCard { CardRank = 3, CardSuit = 2 };
            var cardB = new PokerCard { CardRank = 2, CardSuit = 2 };
            Assert.IsTrue(cardA.CompareTo(cardB) == 1);
        }

        [TestMethod]
        public void TestCompareSameCards()
        {
            var cardA = new PokerCard { CardRank = 3, CardSuit = 2 };
            var cardB = new PokerCard { CardRank = 3, CardSuit = 2 };
            Assert.IsTrue(cardA.CompareTo(cardB) == 0);
        }

        [TestMethod]
        public void TestCompareCardSameRankCards()
        {
            var cardA = new PokerCard { CardRank = 5, CardSuit = 2 };
            var cardB = new PokerCard { CardRank = 5, CardSuit = 1 };
            /* Check for false value instead of expected value.
             */
            //Assert.IsTrue(cardA.CompareTo(cardB) == 0);
            Assert.IsFalse(cardA.CompareTo(cardB) > 0);
        }
    }
}
