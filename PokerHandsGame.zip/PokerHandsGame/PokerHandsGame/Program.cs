﻿using PokerGameHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerHandsGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Example1();
            Example2();
            Example3();
            Example4();
            Console.Read();
        }

        private static void Example1()
        {  
            //example 1  flush win
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });

            var Jen = new PokerHand("jen");
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Diamond });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Spade });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Diamond });

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();
            list.Add(Jen);
            list.Add(Joe);
            list.Add(Bob);
            list.Sort();
            list.Reverse();

            Console.WriteLine("Winner: " + list.First().PlayerName);
            

        }

        private static void Example2()
        {
            //example 2  , 3 kind win
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });

            var Jen = new PokerHand("jen");
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Diamond });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Spade });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Diamond });

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();
            list.Add(Jen);
            list.Add(Joe);
            list.Add(Bob);
            list.Sort();
            list.Reverse();

            Console.WriteLine("Winner: " + list.First().PlayerName);
            
        }

        private static void Example3()
        {
            //example 3  , same pair , Joe win with king 
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });

            var Jen = new PokerHand("jen");
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Diamond });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Three, CardSuit = (int)CardSuits.Spade });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Eight, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Diamond });

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();
            list.Add(Jen);
            list.Add(Joe);
            list.Add(Bob);
            list.Sort();
            list.Reverse();

            Console.WriteLine("Winner: " + list.First().PlayerName);
           
        }

        private static void Example4()
        {
            //example 4  , missing cards, bob win  
            //3 kind, jen win if uncomment out code
            var Joe = new PokerHand("joe");
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Spade });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Heart });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Diamond });
            Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Jack, CardSuit = (int)CardSuits.Heart });
            //Joe.Cards.Add(new PokerCard { CardRank = (int)CardRanks.King, CardSuit = (int)CardSuits.Heart });

            var Jen = new PokerHand("jen");
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Six, CardSuit = (int)CardSuits.Club });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Diamond });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Club });
            //Jen.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Diamond });

            var Bob = new PokerHand("bob");
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Two, CardSuit = (int)CardSuits.Heart });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Five, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Seven, CardSuit = (int)CardSuits.Spade });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ten, CardSuit = (int)CardSuits.Club });
            Bob.Cards.Add(new PokerCard { CardRank = (int)CardRanks.Ace, CardSuit = (int)CardSuits.Club });

            var list = new List<PokerHand>();
            list.Add(Jen);
            list.Add(Joe);
            list.Add(Bob);
            list.Sort();
            list.Reverse();

            Console.WriteLine("Winner: " + list.First().PlayerName);
            
        }
    }
}
